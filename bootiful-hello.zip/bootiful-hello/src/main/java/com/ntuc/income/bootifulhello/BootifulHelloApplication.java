package com.ntuc.income.bootifulhello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootifulHelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootifulHelloApplication.class, args);
	}

}
